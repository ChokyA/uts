package com.example.mobil21

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
